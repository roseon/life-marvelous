﻿using System;
using System.Collections.Generic;
 
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

namespace GLauncher
{
    class ExeHandler
    {
        public static void checkMultipleInstance()
        {
            if (Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length > 1)
            {
                Environment.Exit(0);
            }
        }

        public static void checkRunningGame()
        {
            foreach(Process runningProc in Process.GetProcesses())
            {
                if(runningProc.ProcessName.Contains("sad"))
                {
                    MessageBox.Show("Game is already running!");
                    Environment.Exit(0);
                }
            }
        }

        public static void startGame()
        {
            Process exe = new Process();
            exe.StartInfo.FileName = "notepad.exe";
            exe.Start();
        }
    }
}
