﻿using System;
using System.Collections.Generic;
 
using System.Text;
using System.Net;
using System.Windows.Forms;

namespace GLauncher
{
    class PatchFile
    {
        public bool checkPatchFile(string from)
        {
            try
            {
                WebClient PatchFile = new WebClient();
                PatchFile.DownloadFile(from + "Patch.xml", "Patch.xml");
                return true;
            }
            catch (WebException)
            {
                return false;
            }
        }
    }
}
