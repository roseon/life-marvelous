﻿using System;
using System.Collections.Generic;
 
using System.Windows.Forms;

namespace GLauncher
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ExeHandler.checkMultipleInstance();                     //Check if an instance of launcher is already running
            ExeHandler.checkRunningGame();                          //Check if game is running
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
