﻿using System;
using System.Collections.Generic;
 
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Net;

namespace GLauncher
{
    class XMLHandler
    {
        public static string getSizeOfFile(string fileName)
        {
            string fileSize = "";
            XmlDocument doc = new XmlDocument();
            doc.Load("Patch.xml");
            XmlElement root = doc.DocumentElement;
            XmlNodeList allFiles = root.GetElementsByTagName("PatchElement");
            foreach (XmlNode n in allFiles)
            {
                if (n["Name"].InnerText == fileName)
                {
                    fileSize = n["Size"].InnerText;
                }
            }
            return fileSize;
        }
    }
}
