﻿using System;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace GLauncher
{
    public partial class Form1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("Launcher.dll")]                         
        private static extern bool MakeSerialKey();         
        Stopwatch stopwatch = new Stopwatch();              
        private int current_total_progress = 0;             
        private int current_progress = 0;                  
        private int total_store = 0;                        
        private int allSize = 0;                            
        private int LeftToDownload = 0;                     
        private int toDownloadNumber = 0;                  
        private string[] toDownloadFile = new string[0];    
        private Uri PatchLocation = new Uri("http://bg.sytes.net:8080/LauncherUpdate/");

        public Form1()
        {
            InitializeComponent();                         
        }

        public void increaseDownloadNumber()
        {
            this.toDownloadNumber++;                        
        }

        private void addToDownloadList(string file, int elementCount)
        {
            this.toDownloadFile[elementCount] = file;      
        }

        private void checkPatchFile()
        {
            PatchFile checkPatch = new PatchFile();               
            if (!checkPatch.checkPatchFile(Convert.ToString(this.PatchLocation)))                       
            {
                MessageBox.Show("Cannot find Patch.xml on server!\nPlease try again later!");
                Environment.Exit(0);                                
            }
        }

        public void checkFiles()
        {
            int curr_array_element = 0;             
            Hash hash = new Hash();                 
            XmlDocument doc = new XmlDocument();    
            doc.Load("Patch.xml");                  
            XmlElement root = doc.DocumentElement;  
            XmlNodeList allFiles = root.GetElementsByTagName("PatchElement");   
            foreach (XmlNode n in allFiles)        
            {
                string fileName = n["Name"].InnerText;  
                string fileHash = n["Hash"].InnerText;  
                if (!File.Exists(fileName))             
                {
                    this.allSize += Convert.ToInt32(XMLHandler.getSizeOfFile(fileName)); 
                    this.increaseDownloadNumber();   

                    string[] temp = this.toDownloadFile;    
                    this.toDownloadFile = new string[this.toDownloadNumber]; 
                    int curr_store_element = 0;     
                    foreach (string curr_element in temp) 
                    {
                        this.toDownloadFile[curr_store_element] = curr_element; 
                        curr_store_element++;      
                    }

                    this.addToDownloadList(fileName, curr_array_element);   
                    curr_array_element++;          

                }
                else if (hash.GetMD5HashFromFile(fileName) != fileHash) 
                {
                    this.allSize += Convert.ToInt32(XMLHandler.getSizeOfFile(fileName));  
                    this.increaseDownloadNumber(); 
                    string[] temp = this.toDownloadFile;
                    this.toDownloadFile = new string[this.toDownloadNumber];
                    int curr_store_element = 0;
                    foreach (string curr_element in temp)
                    {
                        this.toDownloadFile[curr_store_element] = curr_element;
                        curr_store_element++;
                    }
                    this.addToDownloadList(fileName, curr_array_element);
                    curr_array_element++;
                }
                else
                {

                }
            }
            if (this.toDownloadNumber == 0) 
            {
                this.LeftToDownload = -1; 
            }
        }

        private void downloadFiles()
        {
            if (this.LeftToDownload == -1)
            {
                this.label5.Visible = false;
                this.label1.Visible = false;
                this.label2.Visible = false;
                this.label3.Visible = false;
                this.label4.Visible = false;
                this.label5.Visible = false;
                this.label5.Visible = false;
                this.label6.Visible = false;
                this.pictureBox8.Visible = false;
                this.pictureBox9.Visible = false;
                this.LetsStart();
            }
            else
            {
                string dpath = Path.GetDirectoryName(this.toDownloadFile[this.LeftToDownload]);
                if (!Directory.Exists(dpath))
                {
                    if (dpath == "")
                    {

                    }
                    else
                    {
                        Directory.CreateDirectory(dpath);
                    }
                    try
                    {
                        this.label3.Text = Convert.ToString(this.LeftToDownload + 1);
                        this.label1.Text = Convert.ToString(this.toDownloadNumber);
                        this.label4.Text = Path.GetFileName(this.toDownloadFile[this.LeftToDownload]);
                        this.label1.Visible = true;
                        this.label2.Visible = true;
                        this.label3.Visible = true;
                        this.label4.Visible = true;
                        this.label6.Visible = true;
                        this.pictureBox8.Visible = true;
                        this.pictureBox9.Visible = true;
                        WebClient downloader = new WebClient();
                        downloader.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                        downloader.DownloadFileCompleted += new AsyncCompletedEventHandler(client_DownloadFileCompleted);
                        string fileToDownload = this.PatchLocation + this.toDownloadFile[this.LeftToDownload];
                        downloader.DownloadFileAsync(new Uri(fileToDownload), this.toDownloadFile[this.LeftToDownload]);
                        this.LeftToDownload++;
                    }
                    catch (WebException ex)
                    {
                        MessageBox.Show(Convert.ToString(ex));
                        Environment.Exit(0);
                    }
                }
            }
        }

        void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            this.stopwatch.Start();
            double bytesIn = double.Parse(e.BytesReceived.ToString());
            double totalBytes = double.Parse(e.TotalBytesToReceive.ToString());
            double percentage = bytesIn / totalBytes * 100;
            double overallpercent = ((this.total_store + this.current_progress) / (double)this.allSize) * 100;
            this.current_total_progress = this.total_store + this.current_progress;
            this.current_progress = Convert.ToInt32(bytesIn);
            this.pictureBox7.Width = Convert.ToInt32(Math.Round(percentage / 100 * 475));
            this.pictureBox1.Width = Convert.ToInt32(Math.Round(overallpercent / 100.0 * 475.0));
           // this.pictureBox8.Location = new System.Drawing.Point(pictureBox1.Width + 14, 51);
            this.label5.Visible = true;
    	}

        void client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (this.LeftToDownload < this.toDownloadNumber) 
            {
                this.total_store += Convert.ToInt32(XMLHandler.getSizeOfFile(this.toDownloadFile[this.LeftToDownload-1])); 
                this.downloadFiles(); 
            }
            else
            {
                this.checkFiles();
                this.label1.Visible = false;
                this.label2.Visible = false;
                this.label3.Visible = false;
                this.label4.Visible = false;
                this.label5.Visible = false;
                this.label5.Visible = false;
                this.label6.Visible = false;
                this.pictureBox8.Visible = false;
                this.pictureBox9.Visible = false;
                this.LetsStart();
            }
    	}

        private void timer1_Tick(object sender, EventArgs e)
        {
            //this.pictureBox8.Location = new System.Drawing.Point(pictureBox1.Width + 12, 51);
            label5.Text = Convert.ToString(Math.Round((this.current_total_progress / 1024) / (this.stopwatch.Elapsed.TotalSeconds))) + " Kb/s";
        }
		
		private void LetsStart()
        {
            MakeSerialKey();                            
            ExeHandler.startGame();                     
            Environment.Exit(0);
        }
		
		private void button1_Click(object sender, EventArgs e)
        {
            this.timer2.Start();
			this.SuspendLayout();
            this.timer1.Enabled = true;                 
            this.stopwatch.Start();                     
            this.pictureBox4.Enabled = false;                      
            this.checkPatchFile();                      
            this.checkFiles();                          
            this.downloadFiles();                       
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            this.pictureBox4.BackgroundImage = Properties.Resources.start_pressed;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox4.BackgroundImage = Properties.Resources.ads;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            this.pictureBox2.BackgroundImage = Properties.Resources.ef_esc_pressed;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Coded by Andrez and designed by Tai", "Gunz Updater", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox2.BackgroundImage = Properties.Resources.ef_esc;
        }

        private void pictureBox6_MouseDown(object sender, MouseEventArgs e)
        {
            this.pictureBox6.BackgroundImage = Properties.Resources.ef_help_pressed;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox6.BackgroundImage = Properties.Resources.ef_help;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            this.pictureBox5.BackgroundImage = Properties.Resources.ef_mini_pressed;
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox5.BackgroundImage = Properties.Resources.ef_mini;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.pictureBox8.Location = new System.Drawing.Point(pictureBox1.Width + 11, 51);
            this.pictureBox9.Location = new System.Drawing.Point(pictureBox7.Width + 11, 82);
        }
    }
}
